#ifndef COLORS_HPP
#define COLORS_HPP

namespace gameColors{
    enum class Colors : short int{
        DEFAULT,
        PACMAN, 
        WALL,
        GENERIC_GHOST, 
        FRIGHTENED_GHOST, 
        RETREAT_GHOST,
        BLINKY, 
        PINKY,
        INKY, 
        CLYDE
    };
}

#endif